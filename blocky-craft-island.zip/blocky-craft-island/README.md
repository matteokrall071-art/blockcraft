# Blocky craft island

A Pen created on CodePen.

Original URL: [https://codepen.io/Limexscape/pen/yybezdp](https://codepen.io/Limexscape/pen/yybezdp).

